clc;
clear;
close all;
disp(' Numerical Experiment 2' );
disp( 'Author: Dr Clement Etienam' )
disp( 'Supervisor: Professor Kody Law' )
load reconstructionyes.out;
load ruthkody.out;
load inputtestactive.out;
load outputtestactive.out;
load ruthclsuterreal.out;
load ruthreconclsuterreal.out;
value=ruthkody;
true=outputtestactive;
x=inputtestactive;

% index=abs(true-value);
% a=find(index>=0.5);
% true(a)=[];
% x(a)=[];
% value(a)=[];

figure()
subplot(2,2,1)
plot(x,true,'xr')
hold on 
plot(x,ruthclsuterreal+1,'.b');
title('(a)-True Function(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('y','\lambda');set(h,'FontSize',20);
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
subplot(2,2,2)
plot(x,true,'+r')
hold on
plot(x,value,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
title('(b)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(2,2,4)
hist(true-value)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(d)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
subplot(2,2,3)
scatter(value,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

load DNN2.out;
load MLP2.out;
figure()
subplot(2,3,1)
scatter(value,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(a)-(CCR)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,2)
scatter(DNN2,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(b)-(MLP)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,3)
scatter(MLP2,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-(DNN)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,4)
hist(true-value)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(d)-Dissimilarity(CCR)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,5)
hist(true-DNN2)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(e)-Dissimilarity(MLP)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,6)
hist(true-MLP2)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(f)-Dissimilarity(DNN)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

figure()
subplot(1,3,1)
plot(x,true,'+r')
hold on
plot(x,value,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
title('(a) Reconstruction','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(1,3,2)
scatter(value,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(b) Accuracy','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(1,3,3)
hist(true-value)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-Dissimilarity','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

figure()
subplot(1,3,2)
plot(x,true,'+r')
hold on
plot(x,MLP2,'.k')
ylim([0 1])
title('(b)-DNN','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','DNN');set(h,'FontSize',20);

subplot(1,3,3)
plot(x,true,'+r')
hold on
plot(x,DNN2,'.k')

title('(c)-MLP','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','MLP');set(h,'FontSize',20);

subplot(1,3,1)
plot(x,true,'+r')
hold on
plot(x,value,'.k')
title('(a)-CCR','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','CCR');set(h,'FontSize',20);