clc;
clear;
close all;
disp(' Numerical Experiment 3' );
disp( 'Author: Dr Clement Etienam' )
disp( 'Supervisor: Professor Kody Law' )

load inpiecewise.out;
load outpiecewise.out;
load ruth.out;
load ruthclsuterreal.out;
load ruthreconclsuterreal.out;
x=inpiecewise;
y1=outpiecewise;

% figure
% 
% plot(x,y1);
% shading flat
% grid off
% title('True Function','FontName','Helvetica', 'Fontsize', 20);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
% colormap('jet')
% set(gca, 'FontName','Helvetica', 'Fontsize', 20)
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])

%saveas(gcf,'figure3a','fig')

% figure()
% 
% for i=1:7
% foo='reconstructionyes';
% fee='.out';
% %folder = strcat(f, sprintf('%.d',i));
% True= importdata(strcat(foo, sprintf('%.d',i),fee));
% % True=True.data;
% ruth(:,i)=True;
% 
% end
% for i=1:7
%     subplot(3,3,i)
% plot(x,y1,'+k');
% hold on
% plot(x,ruth(:,i),'r')
% shading flat
% grid off
% title('1D True Function','FontName','Helvetica', 'Fontsize', 20);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
% colormap('jet')
% set(gca, 'FontName','Helvetica', 'Fontsize', 20)
% set(gcf,'color','white')
% h = legend('True function','Machine');set(h,'FontSize',20);
% 
% end
% 
% figure()
% for i=1:7
%     subplot(3,3,i)
% plot(ruth(:,i),y1,'.b');
% 
% shading flat
% grid off
% title('1D True Function','FontName','Helvetica', 'Fontsize', 13);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
% colormap('jet')
% set(gca, 'FontName','Helvetica', 'Fontsize', 13)
% set(gcf,'color','white')
% 
% end

figure()
subplot(2,2,1)
plot(x,y1,'xr');
hold on 
plot(x,ruthclsuterreal+1,'.b');
shading flat
grid off
title('(a)-True Function(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('y','\lambda');set(h,'FontSize',20);

subplot(2,2,2)
plot(x,y1,'+r');
hold on
plot(x,ruth,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
shading flat
grid off
title('(b)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(2,2,3)
scatter(ruth,y1,'o');
shading flat
grid off
title('(c)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,2,4)
hist(ruth-y1)
shading flat
grid off
title('(d)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

figure()
subplot(1,3,1)
plot(x,y1,'+r')
hold on
plot(x,ruth,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
title('(a) Reconstruction','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(1,3,2)
scatter(ruth,y1,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(b) Accuracy','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(1,3,3)
hist(y1-ruth)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-Dissimilarity','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')