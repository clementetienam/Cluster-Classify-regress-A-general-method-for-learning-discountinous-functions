clc;
clear;
close all;
disp(' Numerical Experiment 3' );
disp( 'Author: Dr Clement Etienam' )
disp( 'Supervisor: Professor Kody Law' )
%% True function
N=100;f=zeros(N,1);
x=linspace(-4,10,N)';
for i=1:N
% if x(i)<-5
%     f(i)=sin(x(i));
if x(i)<4
    f(i)=exp(-x(i)^2/20);
elseif x(i)<6
    f(i)=1;
elseif x(i)<8
    f(i)=-1;
else
    f(i)=0;
end
end
   
facx=max(x)-min(x);
x=(x-min(x))/facx;

y1=f;
facy=max(y1)-min(y1);
y1=20*(y1-min(y1))/facy;
  y2=f*f';
facy2=max(max(y2))-min(min(y2));
y2=20*(y2-min(min(y2)))/facy2;
[X,Z]=meshgrid(x,x);
X2=[X(:),Z(:)];
Y2=y2(:); 

load ruthclsuterreal.out;
load ruthreconclsuterreal.out;
load distort.out;
 
[X,Z]=meshgrid(x,x);

figure
% subplot(2,2,1)
% surfc(x,x,y2)
% shading flat
% %axis([1 100 1 100 ])
% grid off
% title('True function(3D-View)','FontName','Helvetica', 'Fontsize', 20);
% ylabel('X2', 'FontName','Helvetica', 'Fontsize', 20);
% xlabel('X1', 'FontName','Helvetica', 'Fontsize', 20);
% colormap('jet')
% h = colorbar;
% ylabel(h, 'y-Function values','FontName','Helvetica', 'Fontsize', 20);
% set(gca, 'FontName','Helvetica', 'Fontsize', 20)
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])

[X,Y] = meshgrid(1:100,1:100);
subplot(3,3,1)
surf(X',Y',y2)
shading flat
axis([1 100 1 100 ])
grid off
title('(a)-y(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('bone')
%caxis([1 10])
h = colorbar;
ylabel(h, 'y-Function values','FontName','Helvetica', 'Fontsize', 10);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,3,2)
surf(X',Y',reshape(ruthclsuterreal,100,100))

shading flat
axis([1 100 1 100 ])
grid off
title('(b)-\lambda(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('jet')
%caxis([1 10])
h = colorbar;
ylabel(h, '\lambda values','FontName','Helvetica', 'Fontsize', 10);
%set(h, 'ylim', [1 10])
%set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,3,3)
surf(X',Y',y2)
% hold on
% surf(X',Y',y2)
shading flat
axis([1 100 1 100 ])
grid off
title('(c)-True y(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('jet')
%caxis([1 10])
h = colorbar;
ylabel(h, 'y-Function values','FontName','Helvetica', 'Fontsize', 10);
%set(h, 'ylim', [1 10])
%set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

load ruth.out;
ruth=reshape(ruth,100,100);
subplot(3,3,4)
surf(X',Y',reshape(ruthclsuterreal,100,100))

shading flat
axis([1 100 1 100 ])
grid off
title('(d)-\lambda(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('jet')
%caxis([1 10])
h = colorbar;
ylabel(h, '\lambda values','FontName','Helvetica', 'Fontsize', 10);
%set(h, 'ylim', [1 10])
%set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% subplot(2,2,3)
% surfc(x,x,ruth)
% shading flat
% %axis([1 100 1 100 ])
% grid off
% title('Machine Reconstruction','FontName','Helvetica', 'Fontsize', 20);
% ylabel('X2', 'FontName','Helvetica', 'Fontsize', 20);
% xlabel('X1', 'FontName','Helvetica', 'Fontsize', 20);
% colormap('jet')
% h = colorbar;
% ylabel(h, 'y-Function values','FontName','Helvetica', 'Fontsize', 20);
% set(gca, 'FontName','Helvetica', 'Fontsize', 20)
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])

subplot(3,3,5)
surf(X',Y',ruth)

shading flat
axis([1 100 1 100 ])
grid off
title('(e)-CCR(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('jet')
%caxis([1 10])
h = colorbar;
ylabel(h, 'CCR-Function values','FontName','Helvetica', 'Fontsize', 10);
%set(h, 'ylim', [1 10])
%set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,3,6)
surf(X',Y',reshape(ruthreconclsuterreal,100,100))
shading flat
axis([1 100 1 100 ])
grid off
title('(f)-Classifier(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 10);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 10);
colormap('jet')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(3,3,7)
hist(y2(:)-ruth(:))
ylabel('count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(g)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(3,3,8)
scatter(ruth(:),y2(:),'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(h)-Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

zz=1:13;
subplot(3,3,9)
plot(zz,distort)
ylabel('Distortion', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Cluster size', 'FontName','Helvetica', 'Fontsize', 20);
title('(I)-Elbow method','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

figure()
subplot(2,3,3)
surf(X',Y',reshape(ruthreconclsuterreal,100,100))
shading flat
axis([1 100 1 100 ])
grid off
title('(c)-Classifier','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
h = colorbar;
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,3,1)
surf(X',Y',y2)
shading flat
axis([1 100 1 100 ])
grid off
title('(a)-y','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
h = colorbar;
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,3,2)
surf(X',Y',ruth)
shading flat
axis([1 100 1 100 ])
grid off
title('(b)-CCR','FontName','Helvetica', 'Fontsize', 20);
ylabel('X1', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X2', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
%caxis([1 10])
h = colorbar;

set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(2,3,4)
hist(y2(:)-ruth(:))
ylabel('count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(d)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,3,5)
scatter(ruth(:),y2(:),'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(e)-Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')