clc;
clear;
close all;
x=linspace(0,2,1000);
y=x.*(x>=1);
file = fopen('inputtestactive.out','w+'); 
 for k=1:numel(x)                                                                       
 fprintf(file,' %4.4f \n',x(k) );             
 end


 file = fopen('outputtestactive.out','w+'); 
 for k=1:numel(y)                                                                       
 fprintf(file,' %4.4f \n',y(k) );             
 end