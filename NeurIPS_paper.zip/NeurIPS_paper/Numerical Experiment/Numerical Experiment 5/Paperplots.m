clc;
clear;
close all;
load True
a=ff{4,6};
b=ff{4,9};
c=ff{4,10};

load machine;
a1=ff{4,6};
b1=ff{4,9};
c1=ff{4,10};

load Class;
a2=ff{4,6};
b2=ff{4,9};
c2=ff{4,10};

figure()

subplot(4,3,10), 
imagesc(a2);
   title ('(j)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x6','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
subplot(4,3,11), 
imagesc(b2);
  title ('(k)','Fontname','Helvetica','FontSize',20,'fontweight','b')
      
        ylabel('x9','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
 subplot(4,3,12), 
imagesc(c2);
        title ('(l)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x10','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
subplot(4,3,1), 
imagesc(a);
        title ('(a)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x6','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
subplot(4,3,2), 
imagesc(b);
       title ('(b)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x9','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
 subplot(4,3,3), 
imagesc(c);
        title ('(c)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x10','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
   
        subplot(4,3,4), 
imagesc(a1);
        title ('(d)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x6','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
     subplot(4,3,5), 
imagesc(b1);
        title ('(e)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x9','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
   subplot(4,3,6), 
imagesc(c1);
       title ('(f)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x10','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
        
           subplot(4,3,7), 
imagesc(abs(a-a1));
        title ('(g)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x6','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
subplot(4,3,8), 
imagesc(abs(b-b1));
        title ('(h)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x9','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])
   subplot(4,3,9), 
imagesc(abs(c-c1));
        title ('(i)','Fontname','Helvetica','FontSize',20,'fontweight','b')
        ylabel('x10','Fontname','Helvetica','FontSize',20,'fontweight','b')

        xlabel('x4','Fontname','Helvetica','FontSize',20,'fontweight','b')
        
        colormap('jet')

        set(gca, 'FontName','Helvetica', 'Fontsize', 20)
        set(gcf,'color','white')
        set(gca,'xticklabel',[])
        set(gca,'yticklabel',[])