# Generated with SMOP  0.41
from smop.libsmop import *
# convert.m

clc
clear('all')
close_('all')
load('chi')
N=size(chiitg1,2) - 1

y=chiitg1(arange(),N + 1)

hist(y,100)
N=10
X=chiitg1(arange(),arange(1,N))
# convert.m:11
L=length(X)
# convert.m:12
numpts=100    
M=size(chiitg1,1)
# convert.m:26
mean=sum(chiitg1(arange(),arange(1,10))) / M
# convert.m:27
miin=min(chiitg1(arange(),arange(1,10)))
# convert.m:28
maax=max(chiitg1(arange(),arange(1,10)))
# convert.m:29
npts=100
# convert.m:30
for j in arange(1,10).reshape(-1):
    xxx[j,arange()]=linspace(miin(j),maax(j),npts)
# convert.m:32
    
N
for ii in arange(1,N).reshape(-1):
    for j in arange(1,npts).reshape(-1):
        in_=copy(mean)
# convert.m:43
        in_[ii]=xxi[ii,ii](j)
# convert.m:44
        ff[ii,ii][j]=forwarding(in_)
# convert.m:45
        subplot(N,N,dot(N,(ii - 1)) + ii)
        plot(xxi[ii,ii],ff[ii,ii])
        set(gca,'XTick',[])
        set(gcf,'color','white')
        #    subplot(9,9,9*(ii-1)+ii), plot(-0.1*xxi{ii,ii}.^0,linspace(0,max(ff{ii,ii})*1.5));
        for jj in arange(ii + 1,N).reshape(-1):
            xi1,xi2=meshgrid(xxx(ii,arange()),xxx(jj,arange()),nargout=2)
# convert.m:54
            for i in arange(1,npts).reshape(-1):
                for j in arange(1,npts).reshape(-1):
                    in_=copy(mean)
# convert.m:58
                    in_[ii]=xxx(ii,i)
# convert.m:59
                    in_[jj]=xxx(jj,j)
# convert.m:60
                    ff[ii,jj][i,j]=forwarding(in_)
# convert.m:61
            ff1=ff[ii,jj]
# convert.m:65
            if ii == 1 and jj < 9:
                subplot(N,N,dot(N,(jj - 1)) + ii)
                imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                hold
                set(gca,'XTick',[])
                colormap('jet')
                set(gcf,'color','white')
                set(gca,'FontName','Helvetica','Fontsize',13)
            else:
                if jj == N and ii > 1:
                    subplot(N,N,dot(N,(jj - 1)) + ii)
                    imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                    hold
                    set(gca,'YTick',[])
                    colormap('jet')
                    set(gcf,'color','white')
                    set(gca,'FontName','Helvetica','Fontsize',13)
                else:
                    if jj == N and ii == 1:
                        subplot(N,N,dot(N,(jj - 1)) + ii)
                        imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                        hold
                        colormap('jet')
                        set(gcf,'color','white')
                        set(gca,'FontName','Helvetica','Fontsize',13)
                    else:
                        subplot(N,N,dot(N,(jj - 1)) + ii)
                        imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                        hold
                        set(gca,'YTick',[],'XTick',[])
                        colormap('jet')
                        set(gcf,'color','white')
                        set(gca,'FontName','Helvetica','Fontsize',13)
            #subplot(9,9,9*(jj-1)+ii), plot(-0.1,-0.1,'ro','Markersize',10,'Linewidth',2)
    