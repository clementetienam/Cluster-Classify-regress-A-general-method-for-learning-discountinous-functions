clc;
clear;
close all;
disp(' Numerical Experiment 1' );
disp( 'Author: Dr Clement Etienam' )
disp( 'Supervisor: Professor Kody Law' )
load reconstruction.out;
load inputtestactive.out;
load outputtestactive.out;
value=reconstruction;
true=outputtestactive;
x=inputtestactive;

load ruthclsuterreal.out;
load ruthreconclsuterreal.out;
figure()
subplot(2,2,1)
plot(x,true,'xr');
hold on 
plot(x,ruthclsuterreal+1,'.b');
shading flat
grid off
title('(a)-True Function(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('y','\lambda');set(h,'FontSize',20);

subplot(2,2,2)
plot(x,true,'+r');
hold on
plot(x,value,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
shading flat
grid off
title('(b)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(2,2,3)
scatter(value,true,'o');
shading flat
grid off
title('(c)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(2,2,4)
hist(value-true)
shading flat
grid off
title('(d)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')



figure()
subplot(1,3,1)
plot(x,true,'+r')
hold on
plot(x,value,'.k')
hold on 
plot(x,ruthreconclsuterreal+1,'xg');
title('(a) Reconstruction','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(1,3,2)
scatter(value,true,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(b) Accuracy','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')

subplot(1,3,3)
hist(true-value)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-Dissimilarity','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')