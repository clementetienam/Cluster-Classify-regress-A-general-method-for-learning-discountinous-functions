# -*- coding: utf-8 -*-
"""
Created on Tuesday Feb 05 12:05:47 2019

@author: Dr Clement Etienam
Numerical Experiment 2
"""

from __future__ import print_function
print(__doc__)

from sklearn.neural_network import MLPClassifier
import numpy as np

from sklearn.cluster import MiniBatchKMeans
from sklearn.cluster import KMeans

import matplotlib.pyplot as plt

from numpy import linalg as LA

from sklearn.utils import check_random_state

from sklearn.ensemble import RandomForestClassifier
import pickle
from sklearn.metrics import classification_report, confusion_matrix
import pandas as pd
from scipy.spatial.distance import cdist
#------------------Begin Code----------------#
print('Determine the optimum number of clusers')

def optimalK(data, nrefs, maxClusters):
    """
    Calculates KMeans optimal K using Gap Statistic 
    """
    gaps = np.zeros((len(range(1, maxClusters)),))
    resultsdf = pd.DataFrame({'clusterCount':[], 'gap':[]})
    for gap_index, k in enumerate(range(1, maxClusters)):

        # Holder for reference dispersion results
        refDisps = np.zeros(nrefs)

        # For n references, generate random sample and perform kmeans getting resulting dispersion of each loop
        for i in range(nrefs):
            
            # Create new random reference set
            randomReference = np.random.random_sample(size=data.shape)
            
            # Fit to it
            km = KMeans(k)
            km.fit(randomReference)
            
            refDisp = km.inertia_
            refDisps[i] = refDisp

        # Fit cluster to original data and create dispersion
        km = KMeans(k)
        km.fit(data)
        
        origDisp = km.inertia_
        # Calculate gap statistic
        gap = np.log(np.mean(refDisps)) - np.log(origDisp)

        # Assign this loop's gap statistic to gaps
        gaps[gap_index] = gap
        
        resultsdf = resultsdf.append({'clusterCount':k, 'gap':gap}, ignore_index=True)

    return (gaps.argmax() + 1, resultsdf)  # Plus 1 because index of 0 means 1 cluster is optimal, index 2 = 3 clusters are optimal


def run_model(model):
    # build the model on training data
    model.fit(inputtrainclass, outputtrainclass )

    # make predictions for test data
    labelDA = model.predict(inputtest)
    return labelDA
print(' Learn the classifer from the predicted labels from Kmeans')
#model = MLPClassifier(solver= 'lbfgs',max_iter=3000)
print('Predict the classes from the classifier for test data')

    
print(' Learn the classifer from the predicted labels from Kmeans')
model = RandomForestClassifier(n_estimators=2000)
#model = MLPClassifier(solver= 'lbfgs',max_iter=5000)
print('cluster with X and y')
X = open("inputtestactive.out") #533051 by 28
X = np.fromiter(X,float)
X = np.reshape(X,(1000,1), 'F') 
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
(scaler.fit(X))
unie=X
X=(scaler.transform(X))
numruth = len(X[0])
Unieback=scaler.inverse_transform(X)

y = open("outputtestactive.out") #533051 by 28
y = np.fromiter(y,float)
y = np.reshape(y,(1000,1), 'F')  


ydami=y
yruth=y
(scaler.fit(yruth))
yruth=(scaler.transform(yruth))
#X_traind, inputtest, y_traind, outputtest = train_test_split(X, y, test_size=0.5)
#ytest=y
outputtest=y
X_traind=X
y_traind=y
(scaler.fit(y_traind))
y_traind=(scaler.transform(y_traind))
y_traind=numruth*10*y_traind
inputtest=X
numrowstest=len(outputtest)

#inputtrainclass=X
##
#outputtrainclass=y
matrix=np.concatenate((X_traind,yruth), axis=1)
distortions = []
K = range(1,14)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(X)
    kmeanModel.fit(X)
    distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])

# Plot the elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()
plt.savefig('NUM2elbow.eps')     # This is for matplotlib 2.1.2
                                   # preventing the figures from showing
plt.clf()
#matrix=y_traind
max_clusters = np.int(input("Enter the maximum number of clusters you want: ") )
k, gapdf = optimalK(matrix, nrefs=5, maxClusters=max_clusters)
nclusters=k
print ('Optimal k is: ', nclusters)
print('Do the K-means clustering with specified clusters of [X,y] and get the labels')
kmeans =MiniBatchKMeans(n_clusters=nclusters,max_iter=100).fit(matrix)
dd=kmeans.labels_
dd=dd.T
dd=np.reshape(dd,(1000,1))
#-------------------#---------------------------------#
print('Use the labels to train a classifier')
inputtrainclass=X_traind
outputtrainclass=np.reshape(dd,(1000,1))
labelDA=run_model(model)

np.savetxt('ruthclsuterreal.out', np.reshape(dd,(-1,1),'F'), fmt = '%d', newline = '\n')
np.savetxt('ruthreconclsuterreal.out', np.reshape(labelDA,(-1,1),'F'), fmt = '%d', newline = '\n')

print('Split for classifier problem')


X_train=X_traind
X_test=inputtest
y_train=dd
y_test=dd


#-------------------Regression----------------#
print('Learn regression of the clusters with different labels from k-means ' )
print('set the output matrix')
clementanswer=np.zeros((numrowstest,1))

print('Start the regression')
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor
for i in range(nclusters):
    label0=(np.asarray(np.where(y_train == i))).T


##
    #model0 = MLPRegressor(solver= 'lbfgs',max_iter=8000)
    model0 = RandomForestRegressor(n_estimators=2000)
    a0=X_train[label0,:]
    a0=np.reshape(a0,(-1,1),'F')

    b0=yruth[label0,:]
    b0=np.reshape(b0,(-1,1),'F')
    model0.fit(a0, b0)




    print('Time for the prediction')
    labelDA0=(np.asarray(np.where(labelDA == i))).T


##----------------------##------------------------##
    a00=inputtest[labelDA0,:]
    a00=np.reshape(a00,(-1,1),'F')
    #if a00.shape[0]!=0:
    clementanswer[np.ravel(labelDA0),:]=np.reshape(model0.predict(a00),(-1,1))

print(' Compute L2 and R2 for the machine')
#clementanswer=clementanswer/(numruth*10)
clementanswer=scaler.inverse_transform(clementanswer)

outputtest = np.reshape(outputtest, (numrowstest, 1))
Lerrorsparse=(LA.norm(outputtest-clementanswer)/LA.norm(outputtest))**0.5
L_2sparse=1-(Lerrorsparse**2)
#Coefficient of determination
outputreq=np.zeros((numrowstest,1))
for i in range(numrowstest):
    outputreq[i,:]=outputtest[i,:]-np.mean(outputtest)


#outputreq=outputreq.T
CoDspa=1-(LA.norm(outputtest-clementanswer)/LA.norm(outputreq))
CoDsparse=1 - (1-CoDspa)**2 ;
print ('R2 of fit using the machine is :', CoDsparse)
print ('L2 of fit using the machine is :', L_2sparse)

print('Plot figures')

fig = plt.figure()
#plt.subplot(2, 3, 1)
plt.scatter(clementanswer,outputtest, color ='c')
plt.xlabel('Real Output')
plt.ylabel('Machine estimate')


fig = plt.figure()
plt.plot(outputtest, color = 'red', label = 'Real data')
plt.plot(clementanswer, color = 'blue', label = 'Predicted data from Machine')
plt.title('Prediction on toy function')
plt.legend()
plt.show()


np.savetxt('ruthkody.out', np.reshape(clementanswer,(-1,1),'F'), fmt = '%4.6f', newline = '\n')








