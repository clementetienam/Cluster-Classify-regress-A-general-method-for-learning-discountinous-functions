# -*- coding: utf-8 -*-
"""
Created on Tuesday Feb 05 12:05:47 2019

@author: Dr Clement Etienam
This is the code for learning a machine for discountinous Chi function
We will cluster th data first, use that label from the cluster and learn a
classifier then a regressor
This code is very important for Chi-data
"""
from __future__ import print_function
print(__doc__)

from sklearn.neural_network import MLPClassifier
import numpy as np

from sklearn.cluster import MiniBatchKMeans
from sklearn.cluster import KMeans
from sklearn import metrics
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
from datetime import datetime
from numpy import linalg as LA
from numpy import *
from sklearn.utils import check_random_state
from sklearn.ensemble import RandomForestClassifier
import pickle
from sklearn.metrics import classification_report, confusion_matrix
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.metrics import accuracy_score
#------------------Begin Code----------------#
print('Determine the optimum number of clusers')

def optimalK(data, nrefs, maxClusters):
    """
    Calculates KMeans optimal K using Gap Statistic 
    """
    gaps = np.zeros((len(range(1, maxClusters)),))
    resultsdf = pd.DataFrame({'clusterCount':[], 'gap':[]})
    for gap_index, k in enumerate(range(1, maxClusters)):

        # Holder for reference dispersion results
        refDisps = np.zeros(nrefs)

        # For n references, generate random sample and perform kmeans getting resulting dispersion of each loop
        for i in range(nrefs):
            
            # Create new random reference set
            randomReference = np.random.random_sample(size=data.shape)
            
            # Fit to it
            km = KMeans(k)
            km.fit(randomReference)
            
            refDisp = km.inertia_
            refDisps[i] = refDisp

        # Fit cluster to original data and create dispersion
        km = KMeans(k)
        km.fit(data)
        
        origDisp = km.inertia_
        # Calculate gap statistic
        gap = np.log(np.mean(refDisps)) - np.log(origDisp)

        # Assign this loop's gap statistic to gaps
        gaps[gap_index] = gap
        
        resultsdf = resultsdf.append({'clusterCount':k, 'gap':gap}, ignore_index=True)

    return (gaps.argmax() + 1, resultsdf)  # Plus 1 because index of 0 means 1 cluster is optimal, index 2 = 3 clusters are optimal



start_time = datetime.now()
x = np.genfromtxt("chi_itg2.dat",skip_header=1, dtype='float')
print('cluster with X and y')
df=x
test=df
numrows=len(test)    # rows of inout
X=np.log(df[:,0:10])
thisis=X
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
(scaler.fit(X))
X=(scaler.transform(X))
y=test[:,-1]
ydami=np.reshape(y[0:55500],(-1,1))
yruth=ydami
(scaler.fit(yruth))
yruth=(scaler.transform(yruth))


outputtest=y[55499:-1]

inputtrainclass=X[0:55500,:]
numruth = len(inputtrainclass[0])
#
outputtrainclass=np.reshape(y[0:55500],(-1,1))
numrowstest=len(outputtest)
(scaler.fit(outputtrainclass))
outputtrainclass=(scaler.transform(outputtrainclass))
outputtrainclass=numruth*10*outputtrainclass

matrix=np.concatenate((inputtrainclass,outputtrainclass), axis=1)
distortions = []
K = range(1,14)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(X)
    kmeanModel.fit(X)
    distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])

# Plot the elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()
plt.savefig('NUM5elbow.eps')     # This is for matplotlib 2.1.2
                                   # preventing the figures from showing
plt.clf()
"""
max_clusters = np.int(input("Enter the maximum number of clusters you want: ") )
k, gapdf = optimalK(matrix, nrefs=5, maxClusters=max_clusters)
"""
nclusters=2
inputtest=X[55499:-1,:]
print('Do the K-means clustering with 5 clusters of [X,y] and get the labels')
kmeans = MiniBatchKMeans(n_clusters=nclusters,random_state=0,batch_size=6,max_iter=10).fit(matrix)
dd=kmeans.labels_
dd=dd.T
dd=np.reshape(dd,(-1,1))
#-------------------#---------------------------------#
print('Use the labels to train a classifier')
inputtrainclass=X[0:55500,:]
dd=np.reshape(dd,(-1,1))

inputtest=X[55499:-1,:];
#%outputtest=y(290000+1:end,:);
def run_model(model):
    # build the model on training data
    model.fit(inputtrainclass, dd )
    kodyout=model.predict(inputtrainclass)
    # make predictions for test data
    labelDA = model.predict(inputtest)
    ff=accuracy_score(dd, kodyout)*100
    cm = confusion_matrix(dd, kodyout,
                          labels=model.classes_)
    print('The accuracy is',ff)
 
    print(cm)
    return labelDA,kodyout


print(' Learn the classifer from the predicted labels from Kmeans')
model = MLPClassifier(solver= 'lbfgs',max_iter=8000)
print('Predict the classes from the classifier for test data')
labelDA,kodyout=run_model(model)
print('Split for classifier problem')
X_train=inputtrainclass
X_test=inputtest
y_train=dd
y_test=dd
y_traind=outputtrainclass
print('set the output matrix')
clementanswer=np.zeros((numrowstest,1))
print('Start the regression')
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor
for i in range(nclusters):
    label0=(np.asarray(np.where(y_train == i))).T


##
    model0 = MLPRegressor(solver= 'lbfgs',max_iter=8000)
#    model0 = RandomForestRegressor(n_estimators=2000)
    a0=X_train[label0,:]
    a0=np.reshape(a0,(-1,10),'F')
    b0=yruth[label0,:]
    b0=np.reshape(b0,(-1,1),'F')
    #if a0 or b0 !=0:
    model0.fit(a0, b0)
    print('Time for the prediction')
    labelDA0=(np.asarray(np.where(labelDA == i))).T
##----------------------##------------------------##
    a00=inputtest[labelDA0,:]
    a00=np.reshape(a00,(-1,10),'F')
    if a00.shape[0]!=0:
       clementanswer[np.ravel(labelDA0),:]=np.reshape(model0.predict(a00),(-1,1))
#kk=inputtest
#JMmachine=forwarding(kk[:,0],kk[:,1],kk[:,2],kk[:,3],kk[:,4],kk[:,5],kk[:,6],kk[:,7],kk[:,8],kk[:,9],[],[])

print(' Compute L2 and R2 for the machine')
#clementanswer=clementanswer/(numruth*10)
clementanswer=scaler.inverse_transform(clementanswer)



print(' Compute L2 and R2 for the machine')

outputtest = np.reshape(outputtest, (numrowstest, 1))
Lerrorsparse=(LA.norm(outputtest-clementanswer)/LA.norm(outputtest))**0.5
L_2sparse=1-(Lerrorsparse**2)
#Coefficient of determination
outputreq=np.zeros((numrowstest,1))
for i in range(numrowstest):
    outputreq[i,:]=outputtest[i,:]-np.mean(outputtest)


#outputreq=outputreq.T
CoDspa=1-(LA.norm(outputtest-clementanswer)/LA.norm(outputreq))
CoDsparse=1 - (1-CoDspa)**2 ;
print ('R2 of fit using the machine is :', CoDsparse)
print ('L2 of fit using the machine is :', L_2sparse)

print('Plot figures')

fig1 = plt.figure(figsize =(8,8))
fig1.add_subplot(2,2,1)
plt.scatter(clementanswer,outputtest, color ='c')
plt.xlabel('Real Output')
plt.ylabel('Machine estimate')
plt.title('Prediction on Chi')
fig1.add_subplot(2,2,2)
plt.plot(outputtest, color = 'red', label = 'Real data')
plt.plot(clementanswer, color = 'blue', label = 'Predicted data from Machine')
plt.title('Prediction on Chi')
plt.legend()
plt.show()

np.savetxt('reconstructionbadd2.out', np.reshape(clementanswer,(-1,1),'F'), fmt = '%4.6f', newline = '\n')
np.savetxt('trueclusterbadd2.out', np.reshape(dd,(-1,1),'F'), fmt = '%d', newline = '\n')
np.savetxt('reconstructionclusterbadd2.out', np.reshape(kodyout,(-1,1),'F'), fmt = '%d', newline = '\n')


