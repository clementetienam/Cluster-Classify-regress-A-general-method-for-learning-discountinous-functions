# -*- coding: utf-8 -*-
"""
Created on Fri May 24 11:55:50 2019

@author: Dr Clement Etienam
Parallel CCR
"""

import datetime

import os
import shutil
import multiprocessing
import numpy as np
import matplotlib.pyplot as plt
import Globalvariables as glb
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestRegressor


from numpy import linalg as LA

from sklearn.utils import check_random_state

from sklearn.ensemble import RandomForestClassifier
import pickle
from sklearn.metrics import classification_report, confusion_matrix
import pandas as pd

#from sklearn.cluster import MiniBatchKMeans


#import clementparallel



##----------------------------------------------------------------------------------

## Start of Programme

print( 'Parallel CCR ')

oldfolder = os.getcwd()
cores = multiprocessing.cpu_count()
print(' ')
print(' This computer has %d cores, which will all be utilised in parallel '%cores)
#print(' The number of cores to be utilised can be changed in runeclipse.py and writefiles.py ')
print(' ')

start = datetime.datetime.now()
print(str(start))
#------------------Begin Code----------------#
 #Save the classification model
print('Determine the optimum number of clusers')

def optimalK(data, nrefs, maxClusters):
    """
    Calculates KMeans optimal K using Gap Statistic 
    """
    gaps = np.zeros((len(range(1, maxClusters)),))
    resultsdf = pd.DataFrame({'clusterCount':[], 'gap':[]})
    for gap_index, k in enumerate(range(1, maxClusters)):

        # Holder for reference dispersion results
        refDisps = np.zeros(nrefs)

        # For n references, generate random sample and perform kmeans getting resulting dispersion of each loop
        for i in range(nrefs):
            
            # Create new random reference set
            randomReference = np.random.random_sample(size=data.shape)
            
            # Fit to it
            km = KMeans(k)
            km.fit(randomReference)
            
            refDisp = km.inertia_
            refDisps[i] = refDisp

        # Fit cluster to original data and create dispersion
        km = KMeans(k)
        km.fit(data)
        
        origDisp = km.inertia_
        # Calculate gap statistic
        gap = np.log(np.mean(refDisps)) - np.log(origDisp)

        # Assign this loop's gap statistic to gaps
        gaps[gap_index] = gap
        
        resultsdf = resultsdf.append({'clusterCount':k, 'gap':gap}, ignore_index=True)

    return (gaps.argmax() + 1, resultsdf)  # Plus 1 because index of 0 means 1 cluster is optimal, index 2 = 3 clusters are optimal


def run_model(model):
    # build the model on training data
    model.fit(inputtrainclass, outputtrainclass )

    # make predictions for test data
    labelDA = model.predict(inputtest)
    return labelDA




print(' Learn the classifer from the predicted labels from Kmeans')
model = RandomForestClassifier(n_estimators=1000)
print('cluster with X and y')
X = open("inpiecewise.out") #533051 by 28
X = np.fromiter(X,float)
X = np.reshape(X,(1000,1), 'F') 
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
(scaler.fit(X))
X=(scaler.transform(X))
numruth = len(X[0])
Unieback=scaler.inverse_transform(X)


y = open("outpiecewise.out") #533051 by 28
y = np.fromiter(y,float)
y = np.reshape(y,(1000,1), 'F')  

ydami=y
yruth=y
(scaler.fit(yruth))
yruth=(scaler.transform(yruth))

#X_traind, inputtest, y_traind, outputtest = train_test_split(X, y, test_size=0.5)
#ytest=y
outputtest=y
X_traind=X
y_traindd=y
(scaler.fit(y_traindd))
y_traindd=(scaler.transform(y_traindd))
y_traindd=numruth*10*y_traindd
inputtest=X
numrowstest=len(outputtest)


matrix=np.concatenate((X_traind,y_traindd), axis=1)
#nclusters = np.int(input("Enter the number of clusters you want: ") )
max_clusters = np.int(input("Enter the maximum number of clusters you want: ") )
k, gapdf = optimalK(matrix, nrefs=5, maxClusters=max_clusters)
nclusters=k
print('')
print('Do the K-means clustering with 18 clusters of [X,y] and get the labels')
kmeans =KMeans(n_clusters=nclusters,max_iter=100).fit(matrix)
dd=kmeans.labels_
dd=dd.T
dd=np.reshape(dd,(-1,1))
#-------------------#---------------------------------#
print('Use the labels to train a classifier')
inputtrainclass=X_traind
outputtrainclass=np.reshape(dd,(-1,1))
labelDA=run_model(model)

print('Split for classifier problem')


X_train=X_traind
X_test=inputtest
y_train=dd
y_test=dd


#loaded_model = pickle.load(open(filename, 'rb'))
#result = loaded_model.score(inputtest, y_test)
#print('The accuracy from reloaded saved model is',result)


np.savetxt('y_train.out',y_train, fmt = '%4.6f', newline = '\n')
np.savetxt('X_train.out',X_train, fmt = '%4.6f', newline = '\n')
np.savetxt('y_traind.out',yruth, fmt = '%4.6f', newline = '\n')
np.savetxt('labelDA.out',labelDA, fmt = '%d', newline = '\n')
np.savetxt('inputtest.out',inputtest, fmt = '%4.6f', newline = '\n')

a = open('numrowstest.out', 'w')
#a.write('%4.6f',numrowstest)
a.write("%i \n" % (numrowstest))
a.close()

#-------------------Regression----------------#
print('Learn regression of the clusters with different labels from k-means ' )

#clementanswer=np.zeros((numrowstest,1))

print('Start the regression')

oldfolder = os.getcwd()
os.chdir(oldfolder)

##Creating Folders and Copying Simulation Datafiles
print(' Creating the folders and copying the simulation files for the forward problem ')

for j in range(nclusters):
    folder = 'CCRmodel_%d'%(j)
    if os.path.isdir(folder): # value of os.path.isdir(directory) = True
        shutil.rmtree(folder)      
    os.mkdir(folder)
    shutil.copy2('y_train.out',folder)
    shutil.copy2('X_train.out',folder)
    shutil.copy2('y_traind.out',folder)
    shutil.copy2('labelDA.out',folder)
    shutil.copy2('inputtest.out',folder)
    shutil.copy2('numrowstest.out',folder)

print( ' Solving the prediction problem' )
os.chdir(oldfolder)
##
import multiprocessing

import numpy as np
#from sklearn.neural_network import MLPRegressor

import os
from joblib import Parallel, delayed

#
def parad(j):
    
    oldfolder = os.getcwd()
    folder = 'CCRmodel_%d'%(j)
    os.chdir(folder)
    y_train = open("y_train.out") #533051 by 28
    y_train = np.fromiter(y_train,float)
    y_train = np.reshape(y_train,(-1,1), 'F') 
    
    
    X_train = open("X_train.out") #533051 by 28
    X_train = np.fromiter(X_train,float)
    X_train = np.reshape(X_train,(-1,1), 'F') 
    
    y_traind = open("y_traind.out") #533051 by 28
    y_traind = np.fromiter(y_traind,float)
    y_traind = np.reshape(y_traind,(-1,1), 'F') 
    
    labelDA = open("labelDA.out") #533051 by 28
    labelDA = np.fromiter(labelDA,int)
    labelDA = np.reshape(labelDA,(-1,1), 'F') 
    
    
    inputtest = open("inputtest.out") #533051 by 28
    inputtest = np.fromiter(inputtest,float)
    inputtest = np.reshape(inputtest,(-1,1), 'F') 
    
    y_train=np.ravel(y_train)
    label0=(np.asarray(np.where(y_train == j))).T
    label0=label0.astype(np.int64)
    labelDA2=np.ravel(labelDA)
    
    clemm=(np.asarray(np.where(labelDA2 == j))).T
    
    
    model0 = RandomForestRegressor(n_estimators=2000)
    a0=X_train[label0,:]
    a0=np.reshape(a0,(-1,1),'F')

    b0=y_traind[label0,:]
    b0=np.reshape(b0,(-1,1),'F')
    model0.fit(a0, b0)
    

    print('Time for the prediction')
    #labelDAunie=(np.asarray(np.where(labelDA == j))).T
    np.savetxt('labelDAunie.out',clemm, fmt = '%d')
    filename2 = 'regressor_model.sav'
    pickle.dump(model0, open(filename2, 'wb'))

##----------------------##------------------------##
    a00=inputtest[clemm,:]
    a00=np.reshape(a00,(-1,1),'F')
    #if a00.shape[0]!=0:
    
    regresspred=np.reshape(model0.predict(a00),(-1,1))
    regresspred=scaler.inverse_transform(regresspred)
    np.savetxt('regresspredd.out',regresspred, fmt = '%d')
    """
    clementanswer[np.ravel(labelDAunie),:]=np.reshape(model0.predict(a00),(-1,1))
    #global clementanswer
    return clementanswer
    """
    os.chdir(oldfolder)
    print(" cluster %d has been processed"%(j))
    
print('')
clementanswer=np.zeros((numrowstest,1))    
num_cores = multiprocessing.cpu_count()
number_of_realisations = range(nclusters)
Parallel(n_jobs=nclusters, verbose=50)(delayed(
    parad)(j)for j in number_of_realisations)
#os.system('clementparallel.py')

print('book keeping now')
for i in range(nclusters):
    folder = 'CCRmodel_%d'%(i)
    os.chdir(folder) 
    labelDAunie = open("labelDAunie.out") #533051 by 28
    labelDAunie = (np.fromiter(labelDAunie,float))
    labelDAunie=labelDAunie.astype(np.int64)
    labelDAunie = ((np.reshape(labelDAunie,(-1,1), 'F') ))
    
    regresspred = open("regresspredd.out") #533051 by 28
    regresspred = np.fromiter(regresspred,float)
    regresspred = np.reshape(regresspred,(-1,1), 'F') 
    clementanswer[np.ravel(labelDAunie),:]=regresspred
    os.chdir(oldfolder)
    
print(' Compute L2 and R2 for the machine')

outputtest = np.reshape(outputtest, (numrowstest, 1))
Lerrorsparse=(LA.norm(outputtest-clementanswer)/LA.norm(outputtest))**0.5
L_2sparse=1-(Lerrorsparse**2)
#Coefficient of determination
outputreq=np.zeros((numrowstest,1))
for i in range(numrowstest):
    outputreq[i,:]=outputtest[i,:]-np.mean(outputtest)


#outputreq=outputreq.T
CoDspa=1-(LA.norm(outputtest-clementanswer)/LA.norm(outputreq))
CoDsparse=1 - (1-CoDspa)**2 ;
print ('R2 of fit using the machine is :', CoDsparse)
print ('L2 of fit using the machine is :', L_2sparse)

print('Plot figures')

fig = plt.figure()
#plt.subplot(2, 3, 1)
plt.scatter(clementanswer,outputtest, color ='c')
plt.xlabel('Real Output')
plt.ylabel('Machine estimate')


fig = plt.figure()
plt.plot(outputtest, color = 'red', label = 'Real data')
plt.plot(clementanswer, color = 'blue', label = 'Predicted data from Machine')
plt.title('Prediction on toy function')
plt.legend()
plt.show()
