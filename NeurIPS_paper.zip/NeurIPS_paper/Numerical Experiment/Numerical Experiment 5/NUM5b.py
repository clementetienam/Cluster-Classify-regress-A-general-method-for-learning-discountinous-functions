# -*- coding: utf-8 -*-
"""
Created on Wednesday April 04 12:05:47 2019

@author: Dr Clement Etienam

"""
from __future__ import print_function
print(__doc__)
#import sys
def forwardclement(inputtest,Xin,yin):
    

    from sklearn.neural_network import MLPClassifier
    import numpy as np
    import pickle
    from sklearn.cluster import MiniBatchKMeans
    from sklearn.cluster import KMeans
    from sklearn import metrics
    from scipy.spatial.distance import cdist
    import matplotlib.pyplot as plt
    from datetime import datetime
    from numpy import linalg as LA
    
    from sklearn.utils import check_random_state
    from sklearn.ensemble import RandomForestClassifier
   
    from sklearn.metrics import classification_report, confusion_matrix
    import pandas as pd

    from sklearn.metrics import accuracy_score
#------------------Begin Code----------------#
    print('Determine the optimum number of clusers')

    def optimalK(data, nrefs, maxClusters):
        """
        Calculates KMeans optimal K using Gap Statistic 
        """
        gaps = np.zeros((len(range(1, maxClusters)),))
        resultsdf = pd.DataFrame({'clusterCount':[], 'gap':[]})
        for gap_index, k in enumerate(range(1, maxClusters)):

            # Holder for reference dispersion results
            refDisps = np.zeros(nrefs)

            # For n references, generate random sample and perform kmeans getting resulting dispersion of each loop
            for i in range(nrefs):
            
                # Create new random reference set
                randomReference = np.random.random_sample(size=data.shape)
            
            # Fit to it
                km = KMeans(k)
                km.fit(randomReference)
            
                refDisp = km.inertia_
                refDisps[i] = refDisp

            # Fit cluster to original data and create dispersion
            km = KMeans(k)
            km.fit(data)
        
            origDisp = km.inertia_
            # Calculate gap statistic
            gap = np.log(np.mean(refDisps)) - np.log(origDisp)

            # Assign this loop's gap statistic to gaps
            gaps[gap_index] = gap
        
            resultsdf = resultsdf.append({'clusterCount':k, 'gap':gap}, ignore_index=True)

        return (gaps.argmax() + 1, resultsdf)  # Plus 1 because index of 0 means 1 cluster is optimal, index 2 = 3 clusters are optimal


    X=np.log(Xin)

    numrows=len(X)    # rows of inout

    thisis=X
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    (scaler.fit(X))
    X=(scaler.transform(X))
    y=yin
    ydami=np.reshape(y,(-1,1))
    yruth=ydami
    (scaler.fit(yruth))
    yruth=(scaler.transform(yruth))
    
    inputtrainclass=X
    numruth = len(inputtrainclass[0])
#
    outputtrainclass=np.reshape(y,(-1,1))
    
    (scaler.fit(outputtrainclass))
    outputtrainclass=(scaler.transform(outputtrainclass))
    outputtrainclass=numruth*10*outputtrainclass

    matrix=np.concatenate((inputtrainclass,outputtrainclass), axis=1)

    nclusters=5 #we wi use 5 clusters here for the experiment
    
    print('Do the K-means clustering with 5 clusters of [X,y] and get the labels')
    kmeans = MiniBatchKMeans(n_clusters=nclusters,random_state=0,batch_size=6,max_iter=10).fit(matrix)
    dd=kmeans.labels_
    dd=dd.T
    dd=np.reshape(dd,(-1,1))
    #-------------------#---------------------------------#
    print('Use the labels to train a classifier')
    inputtrainclass=X
    dd=np.reshape(dd,(-1,1))
#    def run_model(model):
#        # build the model on training data
#        model.fit(inputtrainclass, dd )
#        labelDA = model.predict(inputtest)
#       
#        return labelDA


    print(' Learn the classifer from the predicted labels from Kmeans')
    model = MLPClassifier(solver= 'lbfgs',max_iter=8000)
    print('Predict the classes from the classifier for test data')
    filename = 'finalized_model.sav'
    loaded_model = pickle.load(open(filename, 'rb'))
    labelDA=loaded_model.predict(inputtest)
    print('Split for classifier problem')
    X_train=inputtrainclass
    X_test=inputtest
    y_train=dd
    y_test=dd
    y_traind=outputtrainclass
    print('set the output matrix')

    print('Start the regression')
    from sklearn.neural_network import MLPRegressor
    from sklearn.ensemble import RandomForestRegressor
    for i in range(nclusters):
        label0=(np.asarray(np.where(y_train == i))).T


        ##
        #model0 = MLPRegressor(solver= 'lbfgs',max_iter=8000)
        model0 = RandomForestRegressor(n_estimators=2000)
        a0=X_train[label0,:]
        a0=np.reshape(a0,(-1,10),'F')
        b0=yruth[label0,:]
        b0=np.reshape(b0,(-1,1),'F')
        #if a0 or b0 !=0:
        model0.fit(a0, b0)
        print('Time for the prediction')
        labelDA0=(np.asarray(np.where(labelDA == i))).T
        ##----------------------##------------------------##
        a00=inputtest[labelDA0,:]
        a00=np.reshape(a00,(-1,10),'F')
        if a00.shape[0]!=0:
            clementanswer=np.reshape(model0.predict(a00),(-1,1))

    clementanswer=scaler.inverse_transform(clementanswer)
    return clementanswer
#if __name__ == '__main__':
#    x = float(sys.argv[1])
#    yy = float(sys.argv[2])
#    zz = float(sys.argv[3])
#    sys.stdout.write(str(forwardclement(x,yy,zz)))