# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 22:12:03 2019

@author: mjkiqce3
"""

from numpy import *
x = genfromtxt("chi_itg.dat",skip_header=1, dtype='float')
print('cluster with X and y')
df=x
test=df
numrows=len(test)    # rows of inout
X=log(df[:,0:10])
thisis=X
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
(scaler.fit(X))
X=(scaler.transform(X))
y=test[:,-1]
ydami=reshape(y[0:290000],(-1,1))
yruth=ydami
(scaler.fit(yruth))
yruth=(scaler.transform(yruth))

chiitg1=thisis
N=10
y=reshape(y,(-1,1))
X=thisis

L=len(X)    # rows of inout
numcolstest = len(X[0])

numpts=100
M=L
# convert.m:26
mean=reshape(sum(thisis,axis=0) / M,(-1,1))
miin=reshape(thisis.min(0),(-1,1))
maax=reshape(thisis.max(0),(-1,1))
# convert.m:29
npts=100
# convert.m:30
xxx = zeros((10,100))
for j in range (10):
    xxx[j,:]=linspace(miin[j,:],maax[j,:],npts)
# convert.m:32
    
N
for ii in range(10):
        #     [ff{ii,ii},xxi{ii,ii}]=ksdensity(reshape(LLAMBDA(ii,ii,(K+1)/2:K+1),(K+1)/2+1,1));
    #[ff{ii,ii},xxi{ii,ii}]=ksdensity(X(:,ii));
    xxi[ii,ii]=xxx[ii,:]
# convert.m:41
    for j in range(npts):
        in_=mean
# convert.m:43
        in_[ii]=xxi[ii,ii](j)
# convert.m:44
        ff[ii,ii][j]=forwarding(in_)
# convert.m:45
    subplot(N,N,dot(N,(ii - 1)) + ii)
    plot(xxi[ii,ii],ff[ii,ii])
    set(gca,'XTick',[])
    set(gcf,'color','white')
        #    subplot(9,9,9*(ii-1)+ii), plot(-0.1*xxi{ii,ii}.^0,linspace(0,max(ff{ii,ii})*1.5));
    for jj in arange(ii + 1,N).reshape(-1):
        xi1,xi2=meshgrid(xxx(ii,arange()),xxx(jj,arange()),nargout=2)
# convert.m:54
        for i in arange(1,npts).reshape(-1):
            for j in arange(1,npts).reshape(-1):
                in_=copy(mean)
# convert.m:58
                in_[ii]=xxx(ii,i)
# convert.m:59
                in_[jj]=xxx(jj,j)
# convert.m:60
                ff[ii,jj][i,j]=forwarding(in_)
# convert.m:61
        ff1=ff[ii,jj]

        if ii == 1 and jj < 9:
                subplot(N,N,dot(N,(jj - 1)) + ii)
                imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                hold
                set(gca,'XTick',[])
                colormap('jet')
                set(gcf,'color','white')
                set(gca,'FontName','Helvetica','Fontsize',13)
        else:
            if jj == N and ii > 1:
                    subplot(N,N,dot(N,(jj - 1)) + ii)
                    imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                    hold
                    set(gca,'YTick',[])
                    colormap('jet')
                    set(gcf,'color','white')
                    set(gca,'FontName','Helvetica','Fontsize',13)
            else:
                if jj == N and ii == 1:
                        subplot(N,N,dot(N,(jj - 1)) + ii)
                        imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                        hold
                        colormap('jet')
                        set(gcf,'color','white')
                        set(gca,'FontName','Helvetica','Fontsize',13)
                else:
                        subplot(N,N,dot(N,(jj - 1)) + ii)
                        imagesc(xi1(1,arange()),xi2(arange(),1),ff1)
                        hold
                        set(gca,'YTick',[],'XTick',[])
                        colormap('jet')
                        set(gcf,'color','white')
                        set(gca,'FontName','Helvetica','Fontsize',13)
            #subplot(9,9,9*(jj-1)+ii), plot(-0.1,-0.1,'ro','Markersize',10,'Linewidth',2)
    
