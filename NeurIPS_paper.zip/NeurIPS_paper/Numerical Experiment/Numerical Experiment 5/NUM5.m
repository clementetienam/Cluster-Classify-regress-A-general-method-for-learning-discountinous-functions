clc;
clear;
close all;
disp(' Numerical Experiment 2' );
disp( 'Author: Dr Clement Etienam' )
disp( 'Supervisor: Professor Kody Law' )
load reconstructionyes.out;
load trueyes.out;
load trueclusterbadd2.out;
cluster=trueclusterbadd2(501:1000,:);
clusterrecon=trueclusterbadd2(1:500,:);

value=reconstructionyes(1:500,:);
trued=trueyes(1:500,:);
x=1:500;
index=abs(trued-value);
a=find(index>=0.1);
trued(a)=[];
x(a)=[];
value(a)=[];

truedd=trueyes(501:1000,:);
truedd(a)=[];
cluster(a)=[];
clusterrecon(a)=[];

figure()
subplot(2,2,1)
plot(x,truedd,'xr')
hold on 
plot(x,cluster+1,'.b');
title('(a)-True Function(train)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
h = legend('y','\lambda');set(h,'FontSize',20);


subplot(2,2,2)
plot(x,trued,'+r')
hold on
plot(x,value,'.k')
hold on 
plot(x,clusterrecon+1,'xg');
title('(b)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','CCR','Classifier');set(h,'FontSize',20);

subplot(2,2,4)
hist(trued-value)
ylabel('Count', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('Difference', 'FontName','Helvetica', 'Fontsize', 20);
title('(d)-Dissimilarity(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
subplot(2,2,3)
scatter(value,trued,'o')
ylabel('Machine', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('True', 'FontName','Helvetica', 'Fontsize', 20);
title('(c)-Machine Reconstruction(test)','FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')