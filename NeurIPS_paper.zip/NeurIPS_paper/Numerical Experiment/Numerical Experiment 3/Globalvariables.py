# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 05:34:10 2019

@author: mjkiqce3
"""
import numpy as np
#nclusters = np.int(input("Enter the number of clusters you want: ") )
y = open("outpiecewise.out") #533051 by 28
y = np.fromiter(y,float)
y = np.reshape(y,(1000,1), 'F')  


outputtest=y

numrowstest=len(outputtest)
