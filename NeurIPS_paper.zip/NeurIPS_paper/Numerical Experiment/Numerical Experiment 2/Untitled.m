clc;
clear;
close all;
load inputtestactive.out;
load outputtestactive.out;
x=inputtestactive;
y=outputtestactive;
net = newff(x',y',200); % ceation of the MLP with 10 hidden neurons (one hidden layer)
 net.trainParam.epochs = 1000; % number of iterations
 net.trainParam.goal = 0.00001; % MSE
 net.trainParam.lr=0.1 ; % training parameter ette
 [net,tr] = train(net,x',y'); % training using LM algorithm
 plotperform(tr) ; % Display different errors
 r = sim(net,x') ; % Simulation of the obtained MLP
 %plot(x,y,'black-',x,r,'black+');  %Plot desired output y and obtained output r of the MLP
 
 figure()
 plot(x,y,'+r')
hold on
plot(x,r','.k')

title('(b)-CCR','FontName','Helvetica', 'Fontsize', 20);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 20);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 20);
colormap('jet')
set(gca, 'FontName','Helvetica', 'Fontsize', 20)
set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
h = legend('True y','CCR');set(h,'FontSize',20);

y=exp([2 1 0.1]);
x=y./sum(y);

mu = softmax(x);